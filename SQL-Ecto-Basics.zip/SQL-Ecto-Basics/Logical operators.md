Using comparison operators, you can only use one operator in `WHERE` But logical operators allows you to use multiple logical operators in one `WHERE`. 

##### List of logical operators

1. `LIKE`
2. `IN`
3. `BETWEEN`
4. `IS NULL`
5. `AND`
6. `OR`
7. `NOT`

Let's see each of them with their equivalent `Ecto` in the coming pages.
